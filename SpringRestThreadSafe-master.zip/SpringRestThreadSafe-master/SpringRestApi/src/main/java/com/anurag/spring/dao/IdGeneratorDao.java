package com.anurag.spring.dao;

/**
 * @author anurag
 *
 */
public interface IdGeneratorDao {
	
	public int doIncrementWithLock() ;

}
